# AI chat integration plan

The app's chat is an offline demo. A real AI companion needs a provider account and a secure backend. Never put provider API keys in Android source, assets, preferences, or the APK.

## Recommended architecture
1. Android app sends `{characterId, language, message}` to your HTTPS backend.
2. Backend authenticates and rate-limits the request.
3. Backend calls the AI provider using a server-side secret manager.
4. Backend returns `{reply, emotion}`; the app renders the reply and maps emotion to an animation.
5. Add a privacy notice, data deletion option, timeouts, content-safety rules, and offline fallback.

## Suggested API contract
- App configuration: `COMPANIYAN_API_BASE_URL` (HTTPS backend URL only).
- Endpoint: `POST /v1/chat`
- Example request: `{"characterId":"mass_buddy","language":"Tamil + English","message":"Remind me to drink water"}`
- Example response: `{"reply":"Thalaiva, water break! 💧","emotion":"excited"}`

The current app does not call a real AI service. No live AI response is claimed until a backend endpoint is configured and tested.

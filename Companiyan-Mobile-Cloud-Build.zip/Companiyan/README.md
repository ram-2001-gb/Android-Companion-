# Companiyan — Android companion starter

A Kotlin + Jetpack Compose starter for a playful Tamil/English daily companion. Package: `com.companiyan.app`.

## Included in this starter
- Compose home screen with animated emotion switching and playful starter copy
- Add and delete daily reminders with custom time
- Reminder persistence using SharedPreferences
- Android notification on reminder; daily re-arming after it fires
- Android Text-to-Speech attempt for reminder messages
- Floating emoji character service (requires the user to grant “Display over other apps”)
- Offline demo chat responses to prove the chat UI flow

## Important limitations before daily use
- **This is source code, not a built APK.** This environment has Java but no Android SDK/Gradle installation, so I could not compile or device-test the APK here.
- Android inexact alarms may be delayed by Doze/battery optimization. Exact alarms require user-granted special access on recent Android versions; reliable delivery should be tested on your phone.
- On Android 13+, notification permission is requested at startup. If denied, notifications will not appear.
- Android Text-to-Speech voice availability depends on installed language data. The app's speech service attempts to split Tamil-script and Latin-script segments and switch locales. Tanglish in Latin script is treated as English.
- The floating buddy is an emoji proof-of-concept, not a draggable 3D model yet. Android requires explicit overlay permission. The current service starts a small overlay and allows tapping it to switch expression.
- Chat is **not connected to a real AI model**. Add a secure backend/API integration before using real AI. Do not embed secret API keys in the APK.
- A receiver attempts to restore daily alarms after reboot, time change, time-zone change, and app replacement. Delivery still needs real-device testing; Android may defer inexact alarms because of Doze/battery settings.

## Build the APK on a computer
1. Install Android Studio (current stable) with Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is fine).
2. Open this `Companiyan` folder in Android Studio and allow Gradle sync.
3. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK normally appears at `app/build/outputs/apk/debug/app-debug.apk`.
5. For personal installation, copy the APK to your Android phone and open it; allow installation from that source if Android asks. For public distribution, create a signed release build.

## Recommended next engineering steps
1. Add reboot rescheduling and an exact-alarm permission/settings flow, with graceful fallback.
2. Add reminder edit/enable/disable controls and configurable repeat days.
3. Replace emoji with a custom 3D-rendered character asset and proper emotion animations.
4. Make overlay draggable and add a stop/hide action.
5. Implement bilingual TTS segmentation and a voice preview/settings screen.
6. Connect chat to a secure backend; add privacy notice and rate limiting.
7. Test notifications, speech, overlay, reboot, battery restrictions, and Android versions on a real device.

## Original Tamil companion personas (updated plan)
The starter now includes a small fictional persona catalog in `CharacterProfile.kt`:
- **Mass Buddy** — energetic, dramatic Tanglish
- **Cheerful Star** — warm, encouraging Tamil/English
- **Creator Buddy** — quirky, meme-loving reminders

The home screen lets the user select a persona and saves the selection in app preferences. The selected persona changes the greeting and demo chat/reminder copy. These are text/emoji prototypes, not final 3D models or generated voice identities.

### Character, voice and licensing guardrails
- Keep the first release to original names, designs, catchphrases, and fictional voices.
- Do not copy an identifiable actor/influencer's face, stage name, signature look, catchphrases, or recognizable voice without a suitable written license/permission. A disclaimer alone does not replace permission.
- If celebrity/influencer packs are added later, track the rights holder, approved assets, permitted territories/platforms, term, commercial uses, voice/model training rights, and takedown process for each pack.
- Use properly licensed fonts, music, sound effects, 3D models, and voice assets; keep their license records in the repository.
- AI chat must disclose that the character is fictional/AI-generated and must not claim to be a real person.

### Next source-code changes
1. Replace emoji avatars with original rigged 3D character assets and map each emotion (`happy`, `excited`, `thinking`, `sleepy`, `proud`) to animation clips.
2. Add a `CharacterRepository`/data model with selectable persona, locale, voice profile, dialogue templates, and asset/license metadata.
3. Add a voice-preview screen and bilingual TTS segmentation; check whether the device has Tamil and English speech data and offer a clear fallback.
4. Route reminders through the selected persona's message templates; keep notification text useful if speech playback is unavailable.
5. Add a secure backend for real AI chat. Keep provider API keys off-device, and implement consent, rate limits, privacy controls, and error handling.
6. Improve reminder reliability: permission-aware exact-alarm scheduling where justified, reboot/time-change rescheduling, notification channels, and testing on real devices with battery restrictions.
7. Make the floating character draggable, dismissible, and accessible; ask for overlay access only after explaining why it is needed.
8. Add tests for persona persistence, scheduling, notification delivery, speech fallback, and character switching.


## Current scope and what is not finished
- This is source code, not a finished production app or verified APK.
- Character art is emoji/Compose animation; custom 3D rigged models have not been created.
- Chat remains offline demo logic. See `AI_BACKEND_SETUP.md` for secure backend integration notes.
- The floating character is an emoji overlay proof-of-concept, not a draggable 3D companion.
- Reminder editing, repeat-day controls, automated tests, release signing, and real-device QA remain.
- No celebrity/influencer identities or cloned voices are included; the personas are fictional.


## Build using only a phone
See `BUILD_FROM_PHONE.md`. The `.github/workflows/build-apk.yml` workflow can build a debug APK on GitHub-hosted runners once the extracted project contents are pushed to a GitHub repository.

# Build status

## Included
- Kotlin + Jetpack Compose app shell and three fictional persona profiles
- Animated expression selector and playful offline demo chat
- Reminder creation/deletion UI and persisted reminders
- Daily alarm re-arming and boot/time/time-zone rescheduling receiver
- Android notifications and Text-to-Speech attempt
- Floating emoji overlay proof-of-concept
- Tamil/English voice locale selection and mixed-script segmentation attempt
- Licensing guardrails and secure AI backend integration notes

## Not included / not verified
- No APK is included because Android SDK, Gradle, and Android platform tools are unavailable in this build environment.
- No real AI API integration, custom 3D assets, celebrity licensing, signed release build, or device QA is included.
- Source code has not been compiled here; open and build it with Android Studio before installation.

## Build on a computer
1. Install Android Studio and Android SDK Platform 35.
2. Open the `Companiyan` folder and sync Gradle.
3. Resolve any dependency/plugin errors.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Test on a real device, including reboot, notification permissions, Tamil TTS availability, and battery optimization.

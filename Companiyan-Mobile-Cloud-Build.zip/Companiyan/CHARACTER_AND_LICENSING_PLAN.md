# Companiyan: Original Character Plan

## Product decision
Version 1 uses original fictional Tamil/Tanglish cartoon companions. It supports broad character archetypes inspired by the energy of cinema and creator culture, but does not imitate any specific real actor, actress, YouTuber, or influencer.

## Initial personas
- **Mass Buddy** — energetic, dramatic, motivational.
- **Cheerful Star** — warm, caring, encouraging.
- **Creator Buddy** — quirky, playful, meme-loving.

## User experience
1. Choose a persona in the home screen.
2. Persona-specific greeting and reminder wording update immediately.
3. Daily reminders use the selected language setting and persona's dialogue templates.
4. Animated emotion and voice are selected independently, so a user can change personality without losing reminder settings.
5. Future character packs can be distributed as assets/configuration rather than hard-coded screen branches.

## Permissions and privacy
- **Notifications:** request notification permission on Android 13+ and explain the benefit before the prompt.
- **Scheduled reminders:** prefer inexact scheduling if a small delay is acceptable. If exact timing is a core feature, use the appropriate Android exact-alarm access flow and handle denied/revoked access.
- **Floating character:** Android's `SYSTEM_ALERT_WINDOW` overlay permission requires the user to explicitly grant access in Settings. Provide a clear explanation and a hide/stop control.
- **Speech:** Android Text-to-Speech can use installed language engines/data; check availability and provide text-only fallback. No microphone permission is needed for text-to-speech. Speech-to-text would need a separate microphone flow.
- **AI chat:** use a backend to protect API credentials; disclose network processing and provide privacy controls before sending user messages to an AI service.

## Rights and licensing checklist
For the original starter, use original character names, designs, writing, and fictional voices. Do not create celebrity likenesses or recognizable voice imitations. If real personalities are introduced later, obtain and document permissions/licenses for likeness, name, voice, image, commercial use, territories, duration, derivative/AI uses, and promotional materials. Also verify rights for every model, texture, font, sound, music track, and voice asset. Keep a takedown/contact process and label AI-generated characters clearly.

This is product planning guidance, not legal advice; seek qualified legal review before commercial launch or licensing real personalities.

## Source files changed
- `app/src/main/java/com/companiyan/app/CharacterProfile.kt` — persona model and original persona catalog.
- `app/src/main/java/com/companiyan/app/MainActivity.kt` — persona selector, persistence, greetings and demo chat responses.
- `README.md` — implementation, build, permissions and licensing notes.

## Next engineering milestones
1. Custom rigged 3D models and emotion animation state machine.
2. Character asset catalog and voice profile settings.
3. Bilingual speech segmentation, voice preview, and TTS availability checks.
4. Persona-specific reminder templates.
5. Secure AI backend, consent, rate limiting, privacy controls.
6. Reminder recovery after reboot/time changes and exact-alarm permission handling.
7. Draggable/dismissible overlay and accessibility improvements.
8. Automated tests and real-device validation.

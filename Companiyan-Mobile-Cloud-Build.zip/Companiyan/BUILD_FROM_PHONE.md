# Build Companiyan using only your Android phone

This ZIP includes a GitHub Actions workflow so the APK can be compiled on a cloud runner instead of on your phone. It is still source code, not an APK.

## Cloud build route (recommended if you have a GitHub account)
1. In your phone browser, open https://github.com/new and create a repository named `Companiyan` (a private repository is fine).
2. GitHub's mobile web uploader is limited for folder uploads. If you can use a mobile code editor/file manager with Git support, extract this ZIP and push the extracted project contents to the repository root. Do not upload only the ZIP file.
3. Confirm `.github/workflows/build-apk.yml` is in the repository.
4. Open the repository's **Actions** tab and enable workflows if prompted.
5. Open **Build Companiyan APK**, tap **Run workflow**, choose `main`, and run it.
6. When the run completes successfully, open that run, scroll to **Artifacts**, and download `companiyan-debug-apk`.
7. Extract the artifact ZIP on your phone; it contains `app-debug.apk`. Tap it to install. If Android blocks installation, allow your browser/file manager to install unknown apps for this one installation.

## Important
- The workflow builds a debug APK, not a Play Store release.
- This is not guaranteed to build successfully until CI compiles it; if it fails, open the Actions run and use the build log to fix the errors.
- The current app is still a prototype: the chat is demo-only, character art is emoji/Compose animation rather than custom 3D, and reminders/voice/floating overlay need real-device testing.
- Never put AI provider API keys or passwords in the repository or APK.
- The workflow uses public GitHub-hosted build runners; GitHub plan limits and repository settings may apply.
